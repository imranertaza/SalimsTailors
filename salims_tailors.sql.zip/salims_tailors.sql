-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 19, 2019 at 04:46 AM
-- Server version: 10.0.31-MariaDB-0ubuntu0.16.04.2
-- PHP Version: 7.0.25-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salims_tailors`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `contact_number` int(11) NOT NULL,
  `type` enum('gent','lady') NOT NULL DEFAULT 'gent',
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `contact_number`, `type`, `details`) VALUES
(15, 'sssss', 2147483647, 'gent', '{"pant":{"jul":"43","mohuri":"43","komor":"43","shamna":"23","back":"23","hatu":"23","hip":"1","thai":"343","high":"22","pocket":"2","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"1"},"shirt":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"court":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"panjabi":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"pajama":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""}}'),
(16, 'ghfd', 15254, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"1","thai":"","high":"","pocket":"2","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"1"},"shirt":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"suit":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"panjabi":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""},"pajama":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""}}'),
(17, '7777', 456354, 'gent', '{"pant":{"jul":"2","mohuri":"2","komor":"2","shamna":"2","back":"2","hatu":"2","hip":"12","thai":"2","high":"2","pocket":"2","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"1"},"shirt":{"jul":"1","buk":"1","put":"1","hata":"1","gola":"1","mohuri":"1","komor":"1","shamna":"1","back":"1","mohoda":"1","hip":"1","cutting":null,"pocket":null,"clolor":null,"plate":null,"shali":null,"loose":null,"istekar":null},"suit":{"jul":"3","buk":"3","put":"3","hata":"3","gola":"3","mohuri":"3","komor":"3","mohora":"","shamna":"3","back":"3","sheste":"3","hip":"3","suit_style":null,"button":null,"round":null,"hand_but":null,"side_open":null,"fiting":null},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","comor":"","shamna":"","mohora":"","hip":"","panjabi_style":null,"design":null,"loose":null},"pajama":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""}}'),
(18, '888888', 8888, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":null,"pocket":null,"clolor":null,"plate":null,"shali":null,"loose":null,"istekar":null},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":null,"button":null,"round":null,"hand_but":null,"side_open":null,"fiting":null},"panjabi":{"jul":"5","buk":"5","put":"5","hata":"5","gola":"5","mohuri":"5","comor":"5","shamna":"5","mohora":"5","hip":"5","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""}}'),
(19, 'ssssssdddd', 2147483647, 'gent', '{"pant":{"jul":"1","mohuri":"2","komor":"3","shamna":"4","back":"5","hatu":"6","hip":"7","thai":"8","high":"9","pocket":"1","hip_pocket":"2","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"10","buk":"11","put":"12","hata":"13","gola":"14","mohuri":"15","komor":"16","shamna":"17","back":"20","mohoda":"19","hip":"18","cutting":"1","pocket":"2","clolor":"1","plate":"1","shali":"1","loose":"1","istekar":"1"},"suit":{"jul":"21","buk":"22","put":"23","hata":"24","gola":"25","mohuri":"26","komor":"27","mohora":"","shamna":"28","back":"30","sheste":"29","hip":"31","suit_style":"1","button":"1","round":"1","hand_but":"1","side_open":"1","fiting":"1"},"panjabi":{"jul":"38","buk":"39","put":"40","hata":"41","gola":"42","mohuri":"43","komor":"44","shamna":"45","mohora":"47","hip":"46","panjabi_style":"2","design":"1","loose":"2"},"pajama":{"jul":"32","mohuri":"32","komor":"32","hip":"2","thai":"32","high":"32","pocket":"2","cuting":"2","bon":"1"}}'),
(20, '111111111', 11111111, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":null,"pocket":null,"clolor":null,"plate":null,"shali":null,"loose":null,"istekar":null},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":null,"button":null,"round":null,"hand_but":null,"side_open":null,"fiting":null},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"","thai":"","high":"","Pocket":"","Hip":"","Taken":"","Shamna Down":"","Back Shape":""}}'),
(21, '555', 555, 'gent', '{"pant":{"jul":"5","mohuri":"5","komor":"5","shamna":"5","back":"5","hatu":"5","hip":"5","thai":"5","high":"5","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"4","buk":"4","put":"4","hata":"4","gola":"4","mohuri":"4","komor":"4","shamna":"4","back":"4","mohoda":"4","hip":"4","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"5","buk":"5","put":"5","hata":"5","gola":"5","mohuri":"5","komor":"5","mohora":"","shamna":"5","back":"5","sheste":"5","hip":"5","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"5","buk":"5","put":"5","hata":"5","gola":"5","mohuri":"5","komor":"5","shamna":"5","mohora":"5","hip":"5","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"3","mohuri":"3","komor":"3","hip":"1","thai":"3","high":"3","pocket":"2","cuting":"1","bon":"1"}}'),
(22, 'sssssss', 34234234, 'gent', '{"pant":{"jul":"4","mohuri":"4","komor":"4","shamna":"4","back":"4","hatu":"4","hip":"4","thai":"4","high":"4","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(23, 'sdfasdf', 545465464, 'gent', '{"pant":{"jul":"4","mohuri":"4","komor":"4","shamna":"4","back":"4","hatu":"4","hip":"4","thai":"4","high":"4","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(24, 'fsdafas', 3453453, 'gent', '{"pant":{"jul":"5","mohuri":"5","komor":"5","shamna":"5","back":"5","hatu":"5","hip":"5","thai":"5","high":"5","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(25, 'dafdsf', 2147483647, 'gent', '{"pant":{"jul":"4","mohuri":"4","komor":"4","shamna":"4","back":"4","hatu":"4","hip":"4","thai":"4","high":"4","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(26, 'sdfadsfasdf', 35345, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(27, 'sdaf', 453453, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(28, 'Syed Imran', 2147483647, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(29, 'sdfadsf', 3453425, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(30, 'Syed Imran', 2147483647, 'gent', '{"pant":{"jul":"4","mohuri":"4","komor":"4","shamna":"4","back":"4","hatu":"4","hip":"4","thai":"4","high":"4","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(31, 'Syed Imran', 456435435, 'gent', '{"pant":{"jul":"5","mohuri":"6","komor":"6","shamna":"6","back":"6","hatu":"6","hip":"6","thai":"6","high":"6","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(32, '', 0, 'gent', '{"pant":{"jul":"","mohuri":"","komor":"","shamna":"","back":"","hatu":"","hip":"","thai":"","high":"","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}'),
(33, 'Syed Imran', 1341343413, 'gent', '{"pant":{"jul":"1","mohuri":"1","komor":"1","shamna":"1","back":"1","hatu":"1","hip":"1","thai":"1","high":"1","pocket":"1","hip_pocket":"1","taken":"1","shamna_down":"3","back_shape":"3","mobile_pocket":"2","folding":"2","shaliy":"2","sticker":"2","cuting":"2"},"shirt":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","back":"","mohoda":"","hip":"","cutting":"1","pocket":"2","clolor":"5","plate":"2","shali":"1","loose":"2","istekar":"1"},"suit":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","mohora":"","shamna":"","back":"","sheste":"","hip":"","suit_style":"1","button":"2","round":"1","hand_but":"1","side_open":"2","fiting":"1"},"panjabi":{"jul":"","buk":"","put":"","hata":"","gola":"","mohuri":"","komor":"","shamna":"","mohora":"","hip":"","panjabi_style":"1","design":"2","loose":"3"},"pajama":{"jul":"","mohuri":"","komor":"","hip":"1","thai":"","high":"","pocket":"2","cuting":"1","bon":"1"}}');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `advance` int(11) NOT NULL,
  `delivary_date` date NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `price`, `advance`, `delivary_date`, `date_time`) VALUES
(1, 22, 400, 300, '0000-00-00', '2018-04-16 07:35:27'),
(2, 23, 3000, 2000, '0000-00-00', '2018-04-16 08:54:32'),
(3, 24, 5455, 445, '0000-00-00', '2018-04-16 08:56:03'),
(4, 25, 555, 555, '0000-00-00', '2018-04-16 08:56:56'),
(5, 26, 435, 434, '0000-00-00', '2018-04-16 09:02:26'),
(6, 27, 34435, 3453, '0000-00-00', '2018-04-16 09:04:05'),
(7, 28, 3453453, 54, '0000-00-00', '2018-04-16 09:07:31'),
(8, 29, 345, 34, '2018-04-18', '2018-04-16 09:12:22'),
(9, 30, 5555, 555, '2018-04-24', '2018-04-16 10:14:44'),
(10, 31, 65565656, 565, '2018-04-16', '2018-04-16 10:17:20'),
(11, 32, 545, 545, '2018-04-23', '2018-04-16 10:19:48'),
(12, 33, 540, 555, '2018-04-24', '2018-04-18 06:22:23');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pro_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(15) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pro_id`, `name`, `price`, `quantity`, `date_time`) VALUES
(1, 'Gija', 700, 30, '2018-02-28 09:01:03'),
(2, 'Raymond', 500, 34, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `lebel` varchar(50) NOT NULL,
  `value` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `lebel`, `value`) VALUES
(1, 'ComName', 'Salims Tailors'),
(2, 'Logo', 'logo.png'),
(3, 'address', 'Jessore, Khulna'),
(4, 'country', 'Bangladesh'),
(5, 'contact_number', '01924329315'),
(6, 'Owner', 'All-Mamun'),
(7, 'ShortName', 'ST');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
